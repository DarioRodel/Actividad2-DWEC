/*Ej1*/
let alojamiento =prompt("Introduce los gastos de alojamiento:");
    alojamiento =parseFloat(alojamiento)
let alimentacion = prompt("Introduce los gastos de alimentación:");
    alimentacion =parseFloat(alimentacion)
let entretenimiento = prompt("Introduce los gastos de entretenimiento:");
    entretenimiento =parseFloat(entretenimiento)

let costoTotal = alojamiento + alimentacion + entretenimiento;
alert('El coste total del viaje es:'+(costoTotal.toFixed(2))+'€');

/*Ej2*/
let edadPerro = parseInt(prompt("Introduce la edad de tu perro en años:"));
let edadHumana = edadPerro * 7;
alert('La edad del perro en años humanos es:'+edadHumana+' años');
/*Ej3*/
let peso = parseFloat(prompt("Introduce tu peso:"));
let altura = parseFloat(prompt("Introduce tu altura:"));
let imc = peso / (altura * altura);
let rango;
    if (imc < 18.5) {
        rango = "Bajo peso";
    } else if (imc >= 18.5 && imc <= 24.9) {
        rango = "Normal";
    } else if (imc >= 25 && imc <= 29.9) {
        rango = "Sobrepeso";
    } else  {
        rango = "Obesidad";
    }
alert('IMC:'+imc.toFixed(2)+', Clasificación:'+ rangos)
/*Ej4*/
let precio = parseFloat(prompt("Introduce el precio del producto:"))
let descuento = parseFloat(prompt("Introduce el descuento:"))
let precioFinal= precio-(precio*(descuento/100))
alert('El precio final es '+precioFinal+'€')
/*Ej5*/
function primo(numero) {
    if (numero < 2) 
        return false
    for (let i = 2; i <= Math.sqrt(numero); i++) {
        if (numero % i === 0) 
            return false
    }
    return true;
}
let num1 = parseInt(prompt("Introduce un numero: "))
let num2 = parseInt(prompt("Introduce otro numero: "))
let primos=' '
for(let i = num1;i<=num2;i++){
    if (primo(i))
        primos+=i+' ';
}
alert('Los numeros primos entre '+num1+' y '+num2+' son '+primos)   
/*Ej6*/
function fibonacci(numero1) {
let secuencia = [0, 1];

    for (let i = 2; i < numero1; i++) {
        secuencia.push(secuencia[i - 1] + secuencia[i - 2]);
    }

    return secuencia.slice(0, n);
}

let n = parseInt(prompt("Introduce el numeros de terminos de Fibonacci: "));
let secuencia = fibonacci(n);
alert('Los primeros'+ n+ 'términos de la secuencia Fibonacci son:'+ secuencia.join(", "));

/*Ej7*/
function celsius_Fahrenheit(celsius) {
    return (celsius * 9 / 5) + 32;
}

function fahrenheit_Celsius(fahrenheit) {
    return (fahrenheit - 32) * 5 / 9;
}
let conversion=parseInt(prompt("Elije el tipo de conversion(1-Celtius-Fahrenheit)(2-Fahrenheit-Celtius) "))

if(conversion===1){
    let temperatura=parseInt(prompt("Dime la temperatura que desees convertir"))
    let resultado=celsius_Fahrenheit(temperatura)
    alert(temperatura+'grados Celtius equivalen a'+resultado.toFixed(2)+'grados Fahrenheit')
}
if(conversion===2){
    let temperatura=parseInt(prompt("Dime la temperatura que desees convertir"))
    let resultado=celsius_Fahrenheit(temperatura)
    alert(temperatura+'grados Fahrenheit equivalen a'+resultado.toFixed(2)+'grados Celtius')
}
else{s
    alert("Alertaaaa errooooooor")
}
/*Ej8*/
function calcularFactorial(num) {
    let resultado = 1;

    for (let i = 2; i <= num; i++) {
        resultado *= i;
    }

    return resultado;
}

let numero = parseInt(pºrompt("Introduce un numero no negativo: "));

if (numero < 0) {
    alert("El numero tiene que ser no negativo");
} else {
    let factorial = calcularFactorial(numero);
    alert('El factorial de ' + numero + ' es ' + factorial);
}
